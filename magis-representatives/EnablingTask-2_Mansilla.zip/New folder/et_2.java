import java.util.*;

public class et_2 {
    public static void main(String[]args) {
        Scanner scanner = new Scanner(System.in);
        
        //Print "Input your age" then read Age 
        System.out.println("Input your age: ");
        Integer age = scanner.nextInt();
        
        //Prepare Variables
        int years =100-age;
        
        
        //Check if years = 0
        if(years != 0) {
            System.out.println("You are not yet 100 years old ");
        }
        else {
            System.out.println("You are 100 years old");
        }
    }
}